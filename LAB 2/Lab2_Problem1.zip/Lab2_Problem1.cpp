/*
 * Author: Manan Patel
 * Class: ECE 6122
 * Last Date Modified: 10/12/2021
 *
 * Description:
 * Random Ant Walk: This program calculates the no of moves required
 * for an ant to place the seeds from the bottommost to the topmost
 * row given the conditions in Lab2 Problem1.
 */

 // necessary imports
#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <stdlib.h>
#include <iomanip>
#include <thread>
#include <time.h>
#include <fstream>

#define UP 0
#define RIGHT 1 
#define DOWN 2
#define LEFT 3 

using namespace std;

struct Grid
{
	/* Grid struct:
	* Represents the state of the ant and the seeds
	* on the 5x5 gird
	*/

	int x_ant = 2;				// starting x loc 
	int y_ant = 2;				// starting y loc
	int seeds_placed = 0;		// increment this when a seed is placed in top row
	vector<int> seed_loc = { 0, 0, 1, 0, 2, 0, 3, 0, 4, 0 };	// {x0, y0, x1, y1, ....}
	bool carrying_seed = false;	// represents if ant is carrying seed
	vector<int> goal_loc = { 0, 4 };


	void try_pick_up_seed()
	{
		/* try_pick_up_seed:
		* Used to check and see if the current square has a seed which
		* can be picked up by the ant
		*/

		int i = 0;
		while (i != 10)
		{
			if (x_ant == seed_loc[i] && y_ant == seed_loc[i + 1])
			{
				seed_loc[i] = -1;					// remove seed loc from list
				seed_loc[i + 1] = -1;
				carrying_seed = true;			   // set ant to carry the seed
				return;
			}
			i += 2;
		}
	}


	void drop_seed()
	{
		/* drop_seed:
		* Used to check if current square has a seed and drop the seed
		* if location is appropriate
		*/

		for (int i = 0; i < 10; i += 2)
		{
			if (seed_loc[i] == x_ant && seed_loc[i+1] == y_ant)
			{
				// seed already present
				return;
			}
		}

		int i = 0;
		for (int i = 0; i < 10; i += 2)
		{
			if (seed_loc[i] == -1)
			{
				seed_loc[i] = x_ant;
				seed_loc[i + 1] = y_ant;
				carrying_seed = false;
				++seeds_placed;
				return;
			}
		}
	}


	bool update_ant(int move)
	{
		/* update_ant:
		* Used to update the location of the ant
		* Arguments:
		* move:	specifies which direction
		* Returns:
		* True: if ant is able to move in the specified direction
		* False: if ant cannot move in that direction
		*/

		switch (move)
		{
		case UP:
			if (y_ant == 4)
			{
				return false;
			}
			else
			{
				++y_ant;
				return true;
			}
			break;
		case RIGHT:
			if (x_ant == 4)
			{
				return false;
			}
			else
			{
				++x_ant;
				return true;
			}
			break;
		case DOWN:
			if (y_ant == 0)
			{
				return false;
			}
			else
			{
				--y_ant;
				return true;
			}
			break;
		default:	// LEFT
			if (x_ant == 0)
			{
				return false;
			}
			else
			{
				--x_ant;
				return true;
			}
			break;
		}
	}


};


void get_avg_moves(int iterations, double& avg_moves)
{
	/* get_avg_moves:
	*	Gets the average number of moves required by the ant given 
	*	a certain number of iterations get_avg_moves:
	* Arguments:
	*	iterations: Number of times to find moves required
	*	avg_moves: pointer to a double location to store the average
	*/

	double no_moves = 0;
	double sum_moves = 0;

	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
	default_random_engine generator(seed);
	uniform_int_distribution<int> distribution(0, 3);

	for (int n = 1; n <= iterations; n++)
	{
		// generate random number in the list {0, 1, 2, 3}
		Grid grid;
		no_moves = 0;
		while (grid.seeds_placed != 5)
		{
			// generate a move
			int move = distribution(generator);

			// update ant location by appling the move
			if (grid.update_ant(move))
			{
				++no_moves;
			}

			// Now check for conditions
			// yes we are carrying a seed
			if (grid.carrying_seed)
			{
				// reached the goal for the current seed
				if (grid.y_ant == 4)
				{
					// try to drop the seed if seed not already present
					grid.drop_seed();
				}
			}
			// not carrying a seed
			else
			{
				// try to pick up seed at every square when you are
				// not carrying a seed
				if (grid.y_ant == 0)
				{
					grid.try_pick_up_seed();
				}
			}
		}
		sum_moves += no_moves;
	}
	avg_moves = sum_moves / iterations;
}


int main()
{

	// get the number of threads to make N_threads
	int N_threads = thread::hardware_concurrency() - 1;			// one required for main

	// dynamically allocate a list with N_threads values
	double* avg_moves_list = new double[N_threads];

	// spawn N_threads threads
	thread* threads = new thread[N_threads];

	// total number of iterations before convergence
	long N = 10000000;

	// No of iterations for each thread
	int remainder = N % N_threads;
	int iterations = N / N_threads;
	int last_iteration = iterations + remainder;

	for (int n = 0; n < N_threads; n++)
	{
		if (n == N_threads - 1)
		{
			iterations = last_iteration;
		}
		threads[n] = thread(get_avg_moves, iterations, ref(avg_moves_list[n]));
	}

	for (int n = 0; n < N_threads; n++)
	{
		threads[n].join();
	}
	
	double sum_moves = 0.0;
	for (int n = 0; n < N_threads; n++)
	{
		sum_moves += avg_moves_list[n];
	}
	double average_moves = sum_moves / N_threads;

	// Write output to file
	ofstream myfile;
	myfile.open("ProblemOne.txt", ios::trunc);
	myfile.precision(9);
	myfile <<  "Number of threads created: " << N_threads + 1 << "\n";
	myfile << "Expected number of steps: " << average_moves << "\n";
	myfile << "Total number of runs needed for solution convergence: " << N;
	myfile.close();
	return 0;
}
