/*
 * Author: Manan Patel
 * Class: ECE 6122
 * Last Date Modified: 10/12/2021
 *
 * Description:
 * Integration: Approximates the value of a definite integral
 * given the number of subdivisions to break the integral down.
 */

// necessary imports
#include <iostream>
#include <omp.h>
#include <thread>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <math.h>

using namespace std;

int main(int argc, char** argv)
{
	long divisions = strtol(argv[1], nullptr, 10);			// get the input from command line
	double lower_limit = 0;
	double upper_limit = log(2) / 7;
	double division_size = (upper_limit - lower_limit) / divisions;

	double integral = 0.0;

	long N_threads = omp_get_max_threads();
	double* sum_list = new double[N_threads];				// will store the sum from each thread
	int remainder = divisions % N_threads;					// when number of divisions is not divisible by N_threads
	double iterations = divisions / N_threads;
	double last_iteration = iterations + remainder;			// the last thread will have more iterations

	#pragma omp parallel
	{
		int tid = omp_get_thread_num();						// get the id of the thread
		double sum_i = 0.0;
		double y_i = 0.0;
		double x_i = lower_limit + division_size / 2 + (double) tid * iterations * division_size;		// depending on the tid, get the starting location

		// for last thread
		if (tid == N_threads - 1)
		{
			iterations = last_iteration;
		}

		// get the sum
		for (int n = 1; n <= iterations; n++)
		{
			y_i = 14 * exp(7 * x_i) * division_size;
			x_i += division_size;
			sum_i += y_i;
		}

		// append sum to the respective location in list
		sum_list[tid] = sum_i;
	}
	
	// adding up sums from each thread
	integral = 0.0;
	for (int n = 0; n < N_threads; n++)
	{
		integral += sum_list[n];
	}

	// output integral to file
	ofstream myfile;
	myfile.open("Lab2Prob2.txt", ios::trunc);
	myfile.precision(10);
	myfile << integral;
	myfile.close();
	
	return 0;
}
